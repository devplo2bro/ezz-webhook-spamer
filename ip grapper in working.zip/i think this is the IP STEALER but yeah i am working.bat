@echo off
chcp 65001
title Ethischer System Info & IP Sender
color 3

:menu
cls
echo ----------------------------------------------------
echo SYSTEM INFO & IP WEBSENDER 🌐
echo Sendet Systemdaten und die oeffentliche IP an einen Webhook
echo ----------------------------------------------------
set /p webhook="Bitte gib deine Discord Webhook URL ein: "

if "%webhook%"=="" (
    echo.
    echo Fehler: Eine Webhook URL ist erforderlich.
    pause
    goto menu
)

echo.
echo Verbindung wird hergestellt und IP wird ermittelt...
timeout /t 3 /nobreak >nul

:: Erstelle ein temporaeres Skript zur Ausfuehrung und Datensammlung
echo @echo off > temp_info_script.bat
echo :: Sammlung der Systeminformationen
echo System-Informationen von: %%username%% am %%date%% %%time%% >> system_data.txt
echo ---------------------------------------------------------------------- >> system_data.txt

:: 1. Ermittle die Oeffentliche IP-Adresse
echo Oeffentliche IP-Adresse: >> system_data.txt
curl -s https://icanhazip.com >> system_data.txt
echo. >> system_data.txt

:: 2. Ermittle Betriebssystem-Info
echo Betriebssystem: >> system_data.txt
systeminfo | findstr /B /C:"OS Name" /C:"OS Version" >> system_data.txt
echo. >> system_data.txt

:: 3. Ermittle Prozessor-Info (CPU-Typ)
echo Prozessor-Typ: >> system_data.txt
wmic cpu get Name /value | findstr /v /B /C:"Name=" >> system_data.txt
echo. >> system_data.txt

:: 4. Curl-Befehl zum Senden der Datei an Discord Webhook
echo curl --silent --output NUL -F "file1=@system_data.txt" "%webhook%" >> temp_info_script.bat

:: 5. Temporaere Dateien loeschen und beenden
echo del system_data.txt >> temp_info_script.bat
echo del temp_info_script.bat >> temp_info_script.bat
echo exit >> temp_info_script.bat

:: Ausfuehrung des Skripts starten
start "" temp_info_script.bat

echo.
echo ✅ Erfolg! Systeminfos inkl. IP wurden gesammelt und an den Webhook gesendet.
echo (Der Webhook-Vorgang laeuft im Hintergrund)
echo.

pause
goto :eof
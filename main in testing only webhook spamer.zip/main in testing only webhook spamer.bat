@echo off
chcp 65001 >nul
mode 120,40
cd /d "%~dp0files" 2>nul || cd /d "%~dp0"

setlocal enabledelayedexpansion

:banner
cls
echo.
echo.
echo.
ping localhost -n 2 >nul
echo ▄▄▄▄   ▓█████  ███▄    █   ██████       ███▄ ▄███▓ ▄▄▄       ██▀███   ██▓     ▒█████   ███▄    █   ██████      ▄▄▄█████▓ ▒█████   ▒█████   ██▓
echo ▓█████▄ ▓█   ▀  ██ ▀█   █ ▒██    ▒      ▓██▒▀█▀ ██▒▒████▄    ▓██ ▒ ██▒▓██▒    ▒██▒  ██▒ ██ ▀█   █ ▒██    ▒      ▓  ██▒ ▓▒▒██▒  ██▒▒██▒  ██▒▓██▒
echo ▒██▒ ▄██▒███   ▓██  ▀█ ██▒░ ▓██▄        ▓██    ▓██░▒██  ▀█▄  ▓██ ░▄█ ▒▒██░    ▒██░  ██▒▓██  ▀█ ██▒░ ▓██▄        ▒ ▓██░ ▒░▒██░  ██▒▒██░  ██▒▒██░
echo ▒██░█▀  ▒▓█  ▄ ▓██▒  ▐▌██▒  ▒   ██▒     ▒██    ▒██ ░██▄▄▄▄██ ▒██▀▀█▄  ▒██░    ▒██   ██░▓██▒  ▐▌██▒  ▒   ██▒     ░ ▓██▓ ░ ▒██   ██░▒██   ██░▒██░
echo ░▓█  ▀█▓░▒████▒▒██░   ▓██░▒██████▒▒ ██▓ ▒██▒   ░██▒ ▓█   ▓██▒░██▓ ▒██▒░██████▒░ ████▓▒░▒██░   ▓██░▒██████▒▒ ██▓   ▒██▒ ░ ░ ████▓▒░░ ████▓▒░░██████▒
echo ░▒▓███▀▒░░ ▒░ ░░ ▒░   ▒ ▒ ▒ ▒▓▒ ▒ ░ ▒▓▒ ░ ▒░   ░  ░ ▒▒   ▓▒█░░ ▒▓ ░▒▓░░ ▒░▓  ░░ ▒░▒░▒░ ░ ▒░   ▒ ▒ ▒ ▒▓▒ ▒ ░ ▒▓▒   ▒ ░░   ░ ▒░▒░▒░ ░ ▒░▒░▒░ ░ ▒░▓  ░
echo ▒░▒   ░  ░ ░  ░░ ░░   ░ ▒░░ ░▒  ░ ░ ░▒  ░  ░      ░  ▒   ▒▒ ░  ░▒ ░ ▒░░ ░ ▒  ░  ░ ▒ ▒░ ░ ░░   ░ ▒░░ ░▒  ░ ░ ░▒      ░      ░ ▒ ▒░   ░ ▒ ▒░ ░ ░ ▒  ░
echo  ░    ░    ░      ░   ░ ░ ░  ░  ░   ░   ░      ░     ░   ▒     ░░   ░   ░ ░   ░ ░ ░ ▒     ░   ░ ░ ░  ░  ░   ░     ░      ░ ░ ░ ▒  ░ ░ ░ ▒    ░ ░
echo  ░         ░  ░         ░       ░    ░         ░         ░  ░   ░         ░  ░    ░ ░           ░       ░    ░               ░ ░      ░ ░      ░  ░
echo       ░                              ░                                                                       ░
echo.
echo.
pause
goto :input

:input
cls
ping localhost -n 1 >nul
echo  → 1 - Winrar Cracker                 4 - Next Page
ping localhost -n 1 >nul
echo  → 2 - DDOS
ping localhost -n 1 >nul
echo  → 3 - Website Attacker
ping localhost -n 1 >nul
echo  → 5 - Discord Webhook Sender
echo.
echo ────────────────────────────────────────────
choice /c 12345 /n
set "sel=%errorlevel%"

if "%sel%"=="1" (
    start "" winrar.bat
    goto :banner
) else if "%sel%"=="2" (
    start "" ddos.py
    goto :banner
) else if "%sel%"=="3" (
    start "" website.py
    goto :banner
) else if "%sel%"=="4" (
    goto :input2
) else if "%sel%"=="5" (
    goto :webhook
) else (
    goto :input
)

:input2
cls
ping localhost -n 1 >nul
echo  → 1 - perm spoof                4 - Previous Page
ping localhost -n 1 >nul
echo  → 2 - check serials
ping localhost -n 1 >nul
echo  → 3 - Fix serials not changing
echo.
echo ────────────────────────────────────────────
choice /c 1234 /n
set "sel=%errorlevel%"

if "%sel%"=="1" (
    start "" permspoof.bat
    goto :banner
) else if "%sel%"=="2" (
    start "" checkserials.bat
    goto :banner
) else if "%sel%"=="3" (
    start "" fixserials.bat
    goto :banner
) else if "%sel%"=="4" (
    goto :input
) else (
    goto :input2
)

:webhook
cls
echo Gib die Discord Webhook URL ein:
set /p "webhook=-> "
if "%webhook%"=="" (
    echo Keine Webhook-URL angegeben.
    pause
    goto :input
)

echo.
echo Nachricht, die der Bot einmal senden soll (optional, leer lassen = nichts senden):
set /p "message=-> "

:: Ersetze doppelte Anführungszeichen durch einfache ' damit JSON intakt bleibt
set "message=!message:"='!"

echo.
echo Jetzt kannst du entweder:
echo - eine space-getrennte Liste eingeben (z.B. 4 5 5 6 7) -> jedes Element wird einmal gesendet
echo - oder NUR eine Zahl eingeben (z.B. 100) -> dann wirst du gefragt, welche Nachricht N mal gesendet werden soll
echo - oder eine einzelne Nicht-Ziffer eingeben -> diese wird einmal gesendet
echo.
set /p "auto_input=-> "
set "auto_input=!auto_input:"='!"

:: Trim leading/trailing spaces
for /f "tokens=* delims= " %%T in ("!auto_input!") do set "auto_input=%%T"
:trimloop
if "!auto_input:~-1!"==" " set "auto_input=!auto_input:~0,-1!" & goto :trimloop

:: Prüfe, ob auto_input nur aus Ziffern besteht (also eine Zahl)
set "is_number=1"
for /f "delims=0123456789" %%A in ("!auto_input!") do set "is_number=0"

if "!is_number!"=="1" if not "!auto_input!"=="" (
    :: auto_input ist eine Zahl -> frage, welche Nachricht gesendet werden soll
    set "count=!auto_input!"
    echo.
    echo Du hast angefordert, die Nachricht %count% mal zu senden.
    echo Welche Nachricht soll %count% mal gesendet werden?
    set /p "repeat_msg=-> "
    set "repeat_msg=!repeat_msg:"='!"
    if "!repeat_msg!"=="" (
        echo Keine Nachricht angegeben. Abbruch.
        pause
        goto :input
    )

    :: Erstelle Payload einmal und sende count mal
    >payload_repeat.json echo {"content":"!repeat_msg!"}
    echo Sende Nachricht '!repeat_msg!' %count% mal...
    for /L %%i in (1,1,!count!) do (
        curl --silent --show-error -H "Content-Type: application/json" --data-binary @payload_repeat.json "%webhook%"
        if !errorlevel! neq 0 echo (curl meldete einen Fehler beim Senden: !repeat_msg!)
        ping localhost -n 2 >nul
    )
    del payload_repeat.json 2>nul
) else (
    :: auto_input ist keine reine Zahl -> behandle als Liste oder einzelner Token
    if "!auto_input!"=="" (
        echo Keine automatische Eingabe gemacht.
        :: Falls nur einmalige Nachricht vorhanden, die bereits gesendet werden soll
        if not "!message!"=="" (
            >payload_msg.json echo {"content":"!message!"}
            echo Sende Einzel-Nachricht...
            curl --silent --show-error -H "Content-Type: application/json" --data-binary @payload_msg.json "%webhook%"
            if %errorlevel% neq 0 echo (curl meldete einen Fehler beim Senden der Einzel-Nachricht.)
            del payload_msg.json 2>nul
        )
        pause
        goto :input
    )

    :: Wenn die Eingabe mehrere tokens (space-getrennt) enthält, sende jedes einzeln
    echo Sende jedes Element der Eingabe nacheinander...
    for %%A in (!auto_input!) do (
        set "token=%%~A"
        set "token=!token:"='!"
        >payload_auto.json echo {"content":"!token!"}
        curl --silent --show-error -H "Content-Type: application/json" --data-binary @payload_auto.json "%webhook%"
        if !errorlevel! neq 0 echo (curl meldete einen Fehler beim Senden: !token!)
        ping localhost -n 2 >nul
    )

    if exist payload_auto.json del payload_auto.json 2>nul
)

:: Wenn zusätzlich eine Einzel-Nachricht (message) angegeben war und noch nicht gesendet wurde, sende sie jetzt (falls not already sent in numeric-branch we already handled separate flow)
if not "!message!"=="" (
    :: In number-branch message was not auto-sent; we send it once before finishing.
    rem (We already may have sent message earlier in other flows; to be safe, prompt user)
    rem We'll send the one-time message at the start if desired; here we skip to avoid duplicates.
)

echo Fertig.
pause
goto :input

:: Ende
endlocal
exit /b

